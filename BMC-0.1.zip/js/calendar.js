angular.module('bmc.calendar', [])

.controller('calendar', function($scope) {
    var myName = "thomas";
    $scope.myName = "thomasjuranek";
});
